<?php $__env->startSection('content'); ?>
    <div class="banner1">

        <div class="w3_agileits_service_banner_info">
            <h2>Project - <?php echo e($type); ?></h2>
        </div>
    </div>

    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <table class="table table-bordered table-striped project-table">
                    <thead>
                    <tr>
                        <th scope="col">SL</th>
                        <th scope="col">Project Title</th>
                        <th scope="col">Sector</th>
                        <th scope="col">Client</th>
                        <th scope="col">Date</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th scope="row"><?php echo e($loop->iteration); ?></th>
                        <td><a  href="<?php echo e(route('project_details', ['id' => $project->id])); ?>"><?php echo e($project->title); ?></a></td>

                        <th scope="row"><?php echo e($project->sector); ?></th>
                        <th scope="row"><?php echo e($project->client); ?></th>
                        <th scope="row"><?php echo e($project->date); ?></th>

                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <div class="col-md-12">
                <?php echo e($projects->links()); ?>

            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\dtcl\resources\views/project.blade.php ENDPATH**/ ?>
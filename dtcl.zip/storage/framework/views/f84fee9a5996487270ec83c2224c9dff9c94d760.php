<?php $__env->startSection('title'); ?>
    Update Team Member
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="box">
                <div class="box-header with-border">
                    <h3 class="box-title">Team Member Information</h3>
                </div>
                <!-- /.box-header -->
                <!-- form start -->
                <form class="form-horizontal" method="POST" enctype="multipart/form-data" action="<?php echo e(route('team.member.update',$team->id)); ?>">
                    <?php echo csrf_field(); ?>

                    <div class="box-body">


                        <div class="form-group <?php echo e($errors->has('name') ? 'has-error' :''); ?>">
                            <label class="col-sm-2 control-label">Name</label>

                            <div class="col-sm-10">
                                <input type="text" class="form-control" placeholder="Enter name"
                                       name="name" value="<?php echo e($team->name); ?>">

                                <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?>
                                <span class="help-block"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>
                        <div class="form-group <?php echo e($errors->has('type') ? 'has-error' :''); ?>">
                            <label class="col-sm-2 control-label">Type</label>

                            <div class="col-sm-4">
                                <select class="form-control" name="type">
                                    <option selected value="<?php echo e($team->type); ?>" ><?php echo e($team->type); ?></option>
                                    <option value="Board of Directors" <?php echo e(old('type') == 'Board of Directors' ? 'selected' : ''); ?>>Board of Directors</option>
                                    <option value="Chief official Team" <?php echo e(old('type') == 'Chief official Team' ? 'selected' : ''); ?>>Chief official Team</option>
                                    <option value="Executive Team" <?php echo e(old('type') == 'Executive Team' ? 'selected' : ''); ?>>Executive Team</option>
                                    <option value="Office staff" <?php echo e(old('type') == 'Office staff' ? 'selected' : ''); ?>>Office staff</option>
                                </select>
                                <?php if ($errors->has('type')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('type'); ?>
                                <span class="help-block"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>

                        <div class="form-group <?php echo e($errors->has('designation') ? 'has-error' :''); ?>">
                            <label class="col-sm-2 control-label">Designation</label>

                            <div class="col-sm-10">
                                <input type="text" class="form-control" placeholder="Enter designation"
                                       name="designation" value="<?php echo e($team->designation); ?>">

                                <?php if ($errors->has('designation')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('designation'); ?>
                                <span class="help-block"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>

                        <div class="form-group <?php echo e($errors->has('image') ? 'has-error' :''); ?>">
                            <label class="col-sm-2 control-label">Image</label>

                            <div class="col-sm-10">
                                <input type="file" class="form-control" name="image">

                                <?php if ($errors->has('image')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('image'); ?>
                                <span class="help-block"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>

                    </div>
                    <!-- /.box-body -->

                    <div class="box-footer">
                        <button type="submit" class="btn btn-primary">Update</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\dtcl\resources\views/admin/team/edit_team_member.blade.php ENDPATH**/ ?>
<?php $__env->startSection('additionalCSS'); ?>


    <style>
        .client {
            text-align: center;
            transition: all 500ms ease;
            margin: 15px 0;
            min-height: 270px;
        }

        .card-title{
            font-size: 16px;
            font-weight: bold;
            margin-top: 10px;
        }
        .client:hover{
            box-shadow: 0 0 5px 0 #e6e6e6;
            cursor: pointer;
        }

        .client img {
            max-width: 100%;
            height: 200px;
            object-fit: cover;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="banner1">
        <div class="w3_agileits_service_banner_info">
            <h2>Clients</h2>
        </div>
    </div>

    <section class="ftco-section inner_main_agile_section">
        <div class="container">
            <h3 class="w3l_header w3_agileits_header">Our <span>Clients</span></h3>
            <p class="sub_para_agile two">Ipsum dolor sit amet consectetur adipisicing elit</p><br>

          <div class="row">
              <h2 class="text-center" style="margin-bottom: 15px;">National</h2>
              <?php $__currentLoopData = $nationals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-3">
                        <div  class="client">
                            <img src="<?php echo e(asset('uploads/client/'.$client->image)); ?>"  alt="<?php echo e($client->name); ?>">
                            <div class="client-text">
                                <h5 class="card-title"><?php echo e($client->name); ?></h5>
                            </div>
                        </div>
                    </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
          <div class="row">
              <h2 class="text-center" style="margin-bottom: 15px;">International</h2>
              <?php $__currentLoopData = $internationals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-3">
                        <div  class="client">
                            <img src="<?php echo e(asset('uploads/client/'.$client->image)); ?>"  alt="<?php echo e($client->name); ?>">
                            <div class="client-text">
                                <h5 class="card-title"><?php echo e($client->name); ?></h5>
                            </div>
                        </div>
                    </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('additionalJS'); ?>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\dtcl\resources\views/client.blade.php ENDPATH**/ ?>
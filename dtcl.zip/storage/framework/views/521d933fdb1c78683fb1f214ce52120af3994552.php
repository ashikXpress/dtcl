<?php $__env->startSection('content'); ?>
    <div class="banner1">

        <div class="w3_agileits_service_banner_info">
            <h2>News</h2>
        </div>
    </div>
    <!-- /blog -->
    <div class="events">
        <div class="container">
            <h3 class="w3l_header w3_agileits_header">Our <span>News</span></h3>
            <p class="sub_para_agile two">Ipsum dolor sit amet consectetur adipisicing elit</p><br>
            <ul id="flexiselDemo1">
                <?php $__currentLoopData = $newses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $news): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li>
                        <div class="w3layouts_event_grid">
                            <div class="w3_agile_event_grid1">
                                <img src="<?php echo e(asset('fontend/images/1.jpg')); ?>" alt=" " class="img-responsive" />
                                <div class="w3_agile_event_grid1_pos">
                                    <p>
                                        <?php echo e(date("d F Y", strtotime($news->uploaded_at))); ?>


                                    </p>
                                </div>

                            </div>
                            <div class="agileits_w3layouts_event_grid1">
                                <h5><a href="<?php echo e(route('news_details', ['id' => $news->id])); ?>"><?php echo e($news->title); ?></a></h5>
                                <p><?php echo Str::words($news->description, 15); ?></p>
                            </div>
                        </div>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </ul>

        </div>

    </div>
    <!-- //blog -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\dtcl\resources\views/news.blade.php ENDPATH**/ ?>
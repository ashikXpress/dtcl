<?php $__env->startSection('title'); ?>
    Add News
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="box">
                <div class="box-header with-border">
                    <h3 class="box-title">News Information</h3>
                </div>
                <!-- /.box-header -->
                <!-- form start -->
                <form class="form-horizontal" method="POST" enctype="multipart/form-data" action="<?php echo e(route('add_news_post')); ?>">
                    <?php echo csrf_field(); ?>

                    <div class="box-body">
                        <div class="form-group <?php echo e($errors->has('title') ? 'has-error' :''); ?>">
                            <label class="col-sm-2 control-label">Title</label>

                            <div class="col-sm-10">
                                <input type="text" class="form-control" placeholder="Enter title"
                                       name="title" value="<?php echo e(old('title')); ?>">

                                <?php if ($errors->has('title')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('title'); ?>
                                <span class="help-block"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>

                        <div class="form-group <?php echo e($errors->has('image') ? 'has-error' :''); ?>">
                            <label class="col-sm-2 control-label">Image</label>

                            <div class="col-sm-10">
                                <input type="file" class="form-control" name="image">

                                <?php if ($errors->has('image')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('image'); ?>
                                <span class="help-block"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>

                        <div class="form-group <?php echo e($errors->has('author') ? 'has-error' :''); ?>">
                            <label class="col-sm-2 control-label">Author</label>

                            <div class="col-sm-10">
                                <input type="text" class="form-control" placeholder="Enter author"
                                       name="author" value="<?php echo e(old('author')); ?>">

                                <?php if ($errors->has('author')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('author'); ?>
                                <span class="help-block"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>

                        <div class="form-group <?php echo e($errors->has('file') ? 'has-error' :''); ?>">
                            <label class="col-sm-2 control-label">File</label>

                            <div class="col-sm-10">
                                <input type="file" class="form-control" name="file">

                                <?php if ($errors->has('file')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('file'); ?>
                                <span class="help-block"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>

                        <div class="form-group <?php echo e($errors->has('upload_date') ? 'has-error' :''); ?>">
                            <label class="col-sm-2 control-label">Upload Date</label>

                            <div class="col-sm-10">
                                <input type="date" class="form-control"
                                       name="upload_date" value="<?php echo e(old('upload_date')); ?>">

                                <?php if ($errors->has('upload_date')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('upload_date'); ?>
                                <span class="help-block"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>

                        <div class="form-group <?php echo e($errors->has('description') ? 'has-error' :''); ?>">
                            <label class="col-sm-2 control-label">Description</label>

                            <div class="col-sm-10">
                                <textarea id="editor1" name="description" rows="10" cols="80"><?php echo e(old('description')); ?></textarea>

                                <?php if ($errors->has('description')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('description'); ?>
                                <span class="help-block"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>
                    </div>
                    <!-- /.box-body -->

                    <div class="box-footer">
                        <button type="submit" class="btn btn-primary">Save</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('additionalJS'); ?>
    <!-- CK Editor -->
    <script src="<?php echo e(asset('themes/back/bower_components/ckeditor/ckeditor.js')); ?>"></script>
    <script>
        $(function () {
            CKEDITOR.replace('editor1');
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\dtcl\resources\views/admin/news/add.blade.php ENDPATH**/ ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title><?php echo e(config('app.name')); ?></title>

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <link rel="icon" href="<?php echo e(asset('fontend/images/favicon.ico')); ?>" type="image/x-icon">

    <!-- Tell the browser to be responsive to screen width -->
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <!-- Bootstrap 3.3.7 -->
    <link rel="stylesheet" href="<?php echo e(asset('themes/back/bower_components/bootstrap/dist/css/bootstrap.min.css')); ?>">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="<?php echo e(asset('themes/back/bower_components/font-awesome/css/font-awesome.min.css')); ?>">
    <!-- Ionicons -->
    <link rel="stylesheet" href="<?php echo e(asset('themes/back/bower_components/Ionicons/css/ionicons.min.css')); ?>">
    <!-- Theme style -->
    <link rel="stylesheet" href="<?php echo e(asset('themes/back/css/AdminLTE.min.css')); ?>">
    <!-- AdminLTE Skins. Choose a skin from the css/skins
         folder instead of downloading all of them to reduce the load. -->
    <link rel="stylesheet" href="<?php echo e(asset('themes/back/css/skins/_all-skins.min.css')); ?>">
    <?php echo $__env->yieldContent('additionalCSS'); ?>

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->

    <!-- Google Font -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
</head>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

    <header class="main-header">
        <!-- Logo -->
        <a href="<?php echo e(route('dashboard')); ?>" class="logo">
            <!-- mini logo for sidebar mini 50x50 pixels -->
            <span class="logo-mini">DTCL</span>
            <!-- logo for regular state and mobile devices -->
            <span class="logo-lg"><b>DTCL</b></span>
        </a>
        <!-- Header Navbar: style can be found in header.less -->
        <nav class="navbar navbar-static-top">
            <!-- Sidebar toggle button-->
            <a href="#" class="sidebar-toggle" data-toggle="push-menu" role="button">
                <span class="sr-only">Toggle navigation</span>
            </a>

            <div class="navbar-custom-menu">
                <ul class="nav navbar-nav">
                    <!-- User Account: style can be found in dropdown.less -->
                    <li class="dropdown user user-menu">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                            <img src="<?php echo e(asset('themes/back/img/avatar.png')); ?>" class="user-image" alt="User Image">
                            <span class="hidden-xs"><?php echo e(Auth::user()->name); ?></span>
                        </a>
                        <ul class="dropdown-menu">
                            <!-- Menu Footer-->
                            <li class="user-footer">
                                <div class="pull-right">
                                    <a href="<?php echo e(route('logout')); ?>" class="btn btn-default btn-flat" onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">Sign out</a>
                                </div>

                                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                    <?php echo csrf_field(); ?>
                                </form>
                            </li>
                        </ul>
                    </li>
                </ul>
            </div>
        </nav>
    </header>
    <!-- Left side column. contains the logo and sidebar -->
    <aside class="main-sidebar">
        <!-- sidebar: style can be found in sidebar.less -->
        <section class="sidebar">
            <!-- sidebar menu: : style can be found in sidebar.less -->
            <ul class="sidebar-menu" data-widget="tree">
                <li class="header">MAIN NAVIGATION</li>

                <?php
                    $subMenu = ['menu_content', 'menu_content_details', 'submenu_content', 'submenu_content_details'];
                ?>

                <li class="treeview <?php echo e(in_array(Route::currentRouteName(), $subMenu) ? 'active' : ''); ?>">
                    <a href="#">
                        <i class="fa fa-circle-o text-red"></i> <span>Page Content</span>
                        <span class="pull-right-container">
                          <i class="fa fa-angle-left pull-right"></i>
                        </span>
                    </a>
                    <ul class="treeview-menu <?php echo e(in_array(Route::currentRouteName(), $subMenu) ? 'active menu-open' : ''); ?>">
                        <li class="<?php echo e(Route::currentRouteName() == 'menu_content' ? 'active' : ''); ?>">
                            <a href="<?php echo e(route('menu_content')); ?>"><i class="fa fa-circle-o"></i> Menu Content</a>
                        </li>
                        <li class="<?php echo e(Route::currentRouteName() == 'submenu_content' ? 'active' : ''); ?>">
                            <a href="<?php echo e(route('submenu_content')); ?>"><i class="fa fa-circle-o"></i> Sub Menu Content</a>
                        </li>
                    </ul>
                </li>

                <?php
                    $subMenu = ['add_project', 'admin_all_project', 'edit_project'];
                ?>

                <li class="treeview <?php echo e(in_array(Route::currentRouteName(), $subMenu) ? 'active' : ''); ?>">
                    <a href="#">
                        <i class="fa fa-circle-o text-red"></i> <span>Project</span>
                        <span class="pull-right-container">
                          <i class="fa fa-angle-left pull-right"></i>
                        </span>
                    </a>
                    <ul class="treeview-menu <?php echo e(in_array(Route::currentRouteName(), $subMenu) ? 'active menu-open' : ''); ?>">
                        <li class="<?php echo e(Route::currentRouteName() == 'add_project' ? 'active' : ''); ?>">
                            <a href="<?php echo e(route('add_project')); ?>"><i class="fa fa-circle-o"></i> Add Project</a>
                        </li>

                        <li class="<?php echo e(Route::currentRouteName() == 'admin_all_project' ? 'active' : ''); ?>">
                            <a href="<?php echo e(route('admin_all_project')); ?>"><i class="fa fa-circle-o"></i> All Projects</a>
                        </li>
                    </ul>
                </li>

                <?php
                    $subMenu = ['add_news', 'admin_all_news', 'edit_news'];
                ?>

                <li class="treeview <?php echo e(in_array(Route::currentRouteName(), $subMenu) ? 'active' : ''); ?>">
                    <a href="#">
                        <i class="fa fa-circle-o text-red"></i> <span>News</span>
                        <span class="pull-right-container">
                          <i class="fa fa-angle-left pull-right"></i>
                        </span>
                    </a>
                    <ul class="treeview-menu <?php echo e(in_array(Route::currentRouteName(), $subMenu) ? 'active menu-open' : ''); ?>">
                        <li class="<?php echo e(Route::currentRouteName() == 'add_news' ? 'active' : ''); ?>">
                            <a href="<?php echo e(route('add_news')); ?>"><i class="fa fa-circle-o"></i> Add News</a>
                        </li>

                        <li class="<?php echo e(Route::currentRouteName() == 'admin_all_news' ? 'active' : ''); ?>">
                            <a href="<?php echo e(route('admin_all_news')); ?>"><i class="fa fa-circle-o"></i> All News</a>
                        </li>
                    </ul>
                </li>

<!--                --><?php
//                    $subMenu = ['add_say', 'admin_all_say', 'edit_say'];
//                ?>





















                <?php
                    $subMenu = ['add_slider', 'admin_all_slider', 'edit_slider'];
                ?>

                <li class="treeview <?php echo e(in_array(Route::currentRouteName(), $subMenu) ? 'active' : ''); ?>">
                    <a href="#">
                        <i class="fa fa-circle-o text-red"></i> <span>Slider</span>
                        <span class="pull-right-container">
                          <i class="fa fa-angle-left pull-right"></i>
                        </span>
                    </a>
                    <ul class="treeview-menu <?php echo e(in_array(Route::currentRouteName(), $subMenu) ? 'active menu-open' : ''); ?>">
                        <li class="<?php echo e(Route::currentRouteName() == 'add_slider' ? 'active' : ''); ?>">
                            <a href="<?php echo e(route('add_slider')); ?>"><i class="fa fa-circle-o"></i> Add Slider</a>
                        </li>

                        <li class="<?php echo e(Route::currentRouteName() == 'admin_all_slider' ? 'active' : ''); ?>">
                            <a href="<?php echo e(route('admin_all_slider')); ?>"><i class="fa fa-circle-o"></i> All Slider</a>
                        </li>
                    </ul>
                </li>

                <?php
                    $subMenu = ['add_gallery_item', 'admin_all_gallery_item', 'edit_gallery_item'];
                ?>

                <li class="treeview <?php echo e(in_array(Route::currentRouteName(), $subMenu) ? 'active' : ''); ?>">
                    <a href="#">
                        <i class="fa fa-circle-o text-red"></i> <span>Gallery</span>
                        <span class="pull-right-container">
                          <i class="fa fa-angle-left pull-right"></i>
                        </span>
                    </a>
                    <ul class="treeview-menu <?php echo e(in_array(Route::currentRouteName(), $subMenu) ? 'active menu-open' : ''); ?>">
                        <li class="<?php echo e(Route::currentRouteName() == 'add_gallery_item' ? 'active' : ''); ?>">
                            <a href="<?php echo e(route('add_gallery_item')); ?>"><i class="fa fa-circle-o"></i> Add Image</a>
                        </li>

                        <li class="<?php echo e(Route::currentRouteName() == 'admin_all_gallery_item' ? 'active' : ''); ?>">
                            <a href="<?php echo e(route('admin_all_gallery_item')); ?>"><i class="fa fa-circle-o"></i> All Images</a>
                        </li>
                    </ul>
                </li>

                <?php
                    $subMenu = ['add.team.member.form','all.team.member','team.member.edit'];
                ?>

                <li class="treeview <?php echo e(in_array(Route::currentRouteName(), $subMenu) ? 'active' : ''); ?>">
                    <a href="#">
                        <i class="fa fa-circle-o text-red"></i> <span>Team Member</span>
                        <span class="pull-right-container">
                          <i class="fa fa-angle-left pull-right"></i>
                        </span>
                    </a>
                    <ul class="treeview-menu <?php echo e(in_array(Route::currentRouteName(), $subMenu) ? 'active menu-open' : ''); ?>">
                        <li class="<?php echo e(Route::currentRouteName() == 'add.team.member.form' ? 'active' : ''); ?>">
                            <a href="<?php echo e(route('add.team.member.form')); ?>"><i class="fa fa-circle-o"></i> Add Team Member</a>
                        </li>
                        <li class="<?php echo e(Route::currentRouteName() == 'all.team.member' ? 'active' : ''); ?>">
                            <a href="<?php echo e(route('all.team.member')); ?>"><i class="fa fa-circle-o"></i> All Team Member</a>
                        </li>

                    </ul>
                </li>

                <?php
                $subMenu = ['add.our.activity.form','all.activity','edit.our.activity'];
                ?>
                <li class="treeview <?php echo e(in_array(Route::currentRouteName(), $subMenu) ? 'active' : ''); ?>">
                    <a href="#">
                        <i class="fa fa-circle-o text-red"></i> <span>Our Activities</span>
                        <span class="pull-right-container">
                          <i class="fa fa-angle-left pull-right"></i>
                        </span>
                    </a>
                    <ul class="treeview-menu <?php echo e(in_array(Route::currentRouteName(), $subMenu) ? 'active menu-open' : ''); ?>">
                        <li class="<?php echo e(Route::currentRouteName() == 'add.our.activity.form' ? 'active' : ''); ?>">
                            <a href="<?php echo e(route('add.our.activity.form')); ?>"><i class="fa fa-circle-o"></i> Add Our Activity</a>
                        </li>
                        <li class="<?php echo e(Route::currentRouteName() == 'all.activity' ? 'active' : ''); ?>">
                            <a href="<?php echo e(route('all.activity')); ?>"><i class="fa fa-circle-o"></i> All Activity</a>
                        </li>

                    </ul>
                </li>

                <?php
                $subMenu = ['add.client.form','all.client','edit.client'];
                ?>
                <li class="treeview <?php echo e(in_array(Route::currentRouteName(), $subMenu) ? 'active' : ''); ?>">
                    <a href="#">
                        <i class="fa fa-circle-o text-red"></i> <span>Client</span>
                        <span class="pull-right-container">
                          <i class="fa fa-angle-left pull-right"></i>
                        </span>
                    </a>
                    <ul class="treeview-menu <?php echo e(in_array(Route::currentRouteName(), $subMenu) ? 'active menu-open' : ''); ?>">
                        <li class="<?php echo e(Route::currentRouteName() == 'add.client.form' ? 'active' : ''); ?>">
                            <a href="<?php echo e(route('add.client.form')); ?>"><i class="fa fa-circle-o"></i> Add Client</a>
                        </li>
                        <li class="<?php echo e(Route::currentRouteName() == 'all.client' ? 'active' : ''); ?>">
                            <a href="<?php echo e(route('all.client')); ?>"><i class="fa fa-circle-o"></i> All Client</a>
                        </li>

                    </ul>
                </li>


            </ul>
        </section>
        <!-- /.sidebar -->
    </aside>

    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
            <h1>
                <?php echo $__env->yieldContent('title'); ?>
            </h1>
        </section>

        <!-- Main content -->
        <section class="content">
            <?php echo $__env->yieldContent('content'); ?>
        </section>
        <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->
    <footer class="main-footer">
        <div class="pull-right hidden-xs">
            <b>Hotline</b> 01884-697775
        </div>
        <strong>Developed by <a target="_blank" href="http://2aitbd.com">2A IT</a></strong>
    </footer>
</div>
<!-- ./wrapper -->

<!-- jQuery 3 -->
<script src="<?php echo e(asset('themes/back/bower_components/jquery/dist/jquery.min.js')); ?>"></script>
<!-- jQuery UI 1.11.4 -->
<script src="<?php echo e(asset('themes/back/bower_components/jquery-ui/jquery-ui.min.js')); ?>"></script>
<!-- Bootstrap 3.3.7 -->
<script src="<?php echo e(asset('themes/back/bower_components/bootstrap/dist/js/bootstrap.min.js')); ?>"></script>
<!-- AdminLTE App -->
<script src="<?php echo e(asset('themes/back/js/adminlte.min.js')); ?>"></script>

<script>
    $(function () {
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
    });
</script>
<?php echo $__env->yieldContent('additionalJS'); ?>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\dtcl\resources\views/layouts/admin.blade.php ENDPATH**/ ?>
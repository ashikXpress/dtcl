<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <title><?php echo e(config('app.name')); ?></title>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <!-- custom-theme -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false);
        function hideURLbar(){ window.scrollTo(0,1); } </script>
    <!-- //custom-theme -->
    <link href="<?php echo e(asset('fontend/css/bootstrap.css')); ?>" rel="stylesheet" type="text/css" media="all" />
    <link href="<?php echo e(asset('fontend/css/JiSlider.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('fontend/css/flexslider.css')); ?>" type="text/css" media="screen" property="" />
    <!-- Owl-carousel-CSS -->
    <link href="<?php echo e(asset('fontend/css/owl.carousel.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('fontend/css/style.css')); ?>" rel="stylesheet" type="text/css" media="all" />
    <!-- font-awesome-icons -->
    <link href="<?php echo e(asset('fontend/css/font-awesome.css')); ?>" rel="stylesheet">
    <!-- //font-awesome-icons -->
    <link href="//fonts.googleapis.com/css?family=Source+Sans+Pro:300,300i,400,400i,600,600i,700,900" rel="stylesheet">
    <?php echo $__env->yieldContent('additionalCSS'); ?>

</head>

<body>
<!-- banner -->
<div class="main_section_agile">
    <div class="agileits_w3layouts_banner_nav">

        <nav class="navbar navbar-default">
            <div class="navbar-header navbar-left">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <h1><a class="navbar-brand" href="index.html"><i class="fa fa-diamond" aria-hidden="true"></i> Consultancy</a></h1>

            </div>

            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse navbar-right" id="bs-example-navbar-collapse-1">
                <nav class="link-effect-2" id="link-effect-2">
                    <ul class="nav navbar-nav">
                        <?php $__currentLoopData = $layoutData['menus']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($menu->subMenus->count()): ?>
                        <li class="active">
                            <a href="<?php echo e(url('/') .'/'.  $menu->url); ?>"id="<?php echo e($menu->id); ?>" class="effect-3"><?php echo e($menu->name); ?></a>
                        </li>

                        <li class="dropdown">
                            <a href="#" class="dropdown-toggle effect-3" data-toggle="dropdown">Short Codes <b class="caret"></b></a>
                            <ul class="dropdown-menu agile_short_dropdown" aria-labelledby="<?php echo e($menu->id); ?>">
                                <?php $__currentLoopData = $menu->subMenus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subitem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><a href="<?php echo e(url('/') .'/'.  $subitem->url); ?>"><?php echo e($subitem->name); ?></a></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                            </ul>
                        </li>
                            <?php else: ?>
                                <li><a href="<?php echo e(url('/') .'/'.  $menu->url); ?>" class="effect-3"><?php echo e($menu->name); ?></a></li>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </nav>

            </div>
        </nav>
        <div class="clearfix"> </div>
    </div>
</div>
<!-- banner -->
<div class="banner-silder">
    <div id="JiSlider" class="jislider">
        <ul>
            <li>
                <div class="w3layouts-banner-top">

                    <div class="container">
                        <div class="agileits-banner-info">

                            <h3>Business Consultancy </h3>
                            <p>Grow Your Business</p>
                            <div class="more">
                                <a href="#" class="hvr-shutter-in-vertical" data-toggle="modal" data-target="#myModal">Read More <i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
            </li>
            <li>
                <div class="w3layouts-banner-top w3layouts-banner-top1">
                    <div class="container">
                        <div class="agileits-banner-info">

                            <h3>Best Business Support</h3>
                            <p>Planning Your Dream</p>
                            <div class="more">
                                <a href="#" class="hvr-shutter-in-vertical" data-toggle="modal" data-target="#myModal">Read More <i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
            </li>
            <li>
                <div class="w3layouts-banner-top w3layouts-banner-top2">
                    <div class="container">
                        <div class="agileits-banner-info">

                            <h3>Business Consultancy </h3>
                            <p>Grow Your Business.</p>
                            <div class="more">
                                <a href="#" class="hvr-shutter-in-vertical" data-toggle="modal" data-target="#myModal">Read More <i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
                            </div>
                        </div>

                    </div>
                </div>
            </li>

        </ul>
    </div>
</div>

<!-- //banner -->
<!-- Modal1 -->
<div class="modal fade" id="myModal2" tabindex="-1" role="dialog">
    <div class="modal-dialog">
        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>

                <div class="signin-form profile">
                    <h3 class="agileinfo_sign">Sign In</h3>
                    <div class="login-form">
                        <form action="#" method="post">
                            <input type="email" name="email" placeholder="E-mail" required="">
                            <input type="password" name="password" placeholder="Password" required="">
                            <div class="tp">
                                <input type="submit" value="Sign In">
                            </div>
                        </form>
                    </div>
                    <div class="login-social-grids">
                        <ul>
                            <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                            <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                            <li><a href="#"><i class="fa fa-rss"></i></a></li>
                        </ul>
                    </div>
                    <p><a href="#" data-toggle="modal" data-target="#myModal3" > Don't have an account?</a></p>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- //Modal1 -->
<!-- Modal2 -->
<div class="modal fade" id="myModal3" tabindex="-1" role="dialog">
    <div class="modal-dialog">
        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>

                <div class="signin-form profile">
                    <h3 class="agileinfo_sign">Sign Up</h3>
                    <div class="login-form">
                        <form action="#" method="post">
                            <input type="text" name="name" placeholder="Username" required="">
                            <input type="email" name="email" placeholder="Email" required="">
                            <input type="password" name="password" placeholder="Password" required="">
                            <input type="password" name="password" placeholder="Confirm Password" required="">
                            <input type="submit" value="Sign Up">
                        </form>
                    </div>
                    <p><a href="#"> By clicking register, I agree to your terms</a></p>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- //Modal2 -->
<!-- Modal2 -->
<div class="modal fade" id="myModal4" tabindex="-1" role="dialog">
    <div class="modal-dialog">
        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>

                <div class="signin-form profile">

                    <div class="login-form">
                        <form action="#" method="post">
                            <input type="text" name="name" placeholder="Username" required="">
                            <input type="email" name="email" placeholder="Email" required="">
                            <input type="password" name="password" placeholder="Password" required="">
                            <input type="text" name="subject" placeholder="Subject" required="">
                            <textarea name="Comments" placeholder="Message" required=""></textarea>
                            <input type="submit" value="SUBMIT">
                        </form>
                    </div>

                </div>
            </div>
        </div>
    </div>
</div>
<!-- //Modal2 -->
<!-- bootstrap-pop-up -->
<div class="modal video-modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModal">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">

                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            </div>
            <section>
                <div class="modal-body">
                    <h5>Consultancy</h5>
                    <img src="<?php echo e(asset('fontend/images/2.jpg')); ?>" alt=" " class="img-responsive" />
                    <p>Ut enim ad minima veniam, quis nostrum
                        exercitationem ullam corporis suscipit laboriosam,
                        nisi ut aliquid ex ea commodi consequatur? Quis autem
                        vel eum iure reprehenderit qui in ea voluptate velit
                        e.
                        <i>" Quis autem vel eum iure reprehenderit qui in ea voluptate velit
                            esse quam nihil molestiae consequatur.</i></p>
                </div>
            </section>
        </div>
    </div>
</div>
<!-- //bootstrap-pop-up -->
<?php echo $__env->yieldContent('content'); ?>
<!-- footer -->
<div class="footer">
    <div class="container">
        <div class="w3_agile_footer_grids">
            <div class="col-md-4 w3_agile_footer_grid">
                <h3>Latest Tweets</h3>
                <ul class="agile_footer_grid_list">
                    <li><i class="fa fa-twitter" aria-hidden="true"></i>Nam libero tempore, cum soluta nobis est eligendi optio
                        cumque nihil impedit. <span>1 day ago</span></li>
                    <li><i class="fa fa-twitter" aria-hidden="true"></i>Itaque earum rerum hic tenetur a sapiente delectus <a href="mailto:info@mail.com">info@mail.com</a>
                        cumque nihil impedit. <span>2 days ago</span></li>
                </ul>
            </div>
            <div class="col-md-4 w3_agile_footer_grid">
                <h3>Navigation</h3>
                <ul class="agileits_w3layouts_footer_grid_list">
                    <li><i class="fa fa-long-arrow-right" aria-hidden="true"></i><a href="index.html">Home</a></li>
                    <li><i class="fa fa-long-arrow-right" aria-hidden="true"></i><a href="services.html">Services</a></li>
                    <li><i class="fa fa-long-arrow-right" aria-hidden="true"></i><a href="portfolio.html">Portfolio</a></li>
                    <li><i class="fa fa-long-arrow-right" aria-hidden="true"></i><a href="mail.html">Mail Us</a></li>
                </ul>
            </div>
            <div class="col-md-4 w3_agile_footer_grid">
                <h3>Instagram Posts</h3>
                <div class="w3_agileits_footer_grid_left">
                    <a href="#" data-toggle="modal" data-target="#myModal">
                        <img src="<?php echo e(asset('fontend/images/7.jpg')); ?>" alt=" " class="img-responsive" />
                    </a>
                </div>
                <div class="w3_agileits_footer_grid_left">
                    <a href="#" data-toggle="modal" data-target="#myModal">
                        <img src="<?php echo e(asset('fontend/images/8.jpg')); ?>" alt=" " class="img-responsive" />
                    </a>
                </div>
                <div class="w3_agileits_footer_grid_left">
                    <a href="#" data-toggle="modal" data-target="#myModal">
                        <img src="<?php echo e(asset('fontend/images/3.jpg')); ?>" alt=" " class="img-responsive" />
                    </a>
                </div>
                <div class="w3_agileits_footer_grid_left">
                    <a href="#" data-toggle="modal" data-target="#myModal">
                        <img src="<?php echo e(asset('fontend/images/2.jpg')); ?>" alt=" " class="img-responsive" />
                    </a>
                </div>
                <div class="w3_agileits_footer_grid_left">
                    <a href="#" data-toggle="modal" data-target="#myModal">
                        <img src="<?php echo e(asset('fontend/images/4.jpg')); ?>" alt=" " class="img-responsive" />
                    </a>
                </div>
                <div class="w3_agileits_footer_grid_left">
                    <a href="#" data-toggle="modal" data-target="#myModal">
                        <img src="<?php echo e(asset('fontend/images/1.jpg')); ?>" alt=" " class="img-responsive" />
                    </a>
                </div>
                <div class="clearfix"> </div>
            </div>
            <div class="clearfix"> </div>
        </div>
        <div class="w3_newsletter_footer_grids">
            <div class="w3_newsletter_footer_grid_left">
                <form action="#" method="post">
                    <input type="email" name="Email" placeholder="Enter Your Email...." required="">
                    <input type="submit" value="SEND">
                </form>
            </div>
        </div>
        <div class="w3ls_address_mail_footer_grids">
            <div class="col-md-4 w3ls_footer_grid_left">
                <div class="wthree_footer_grid_left">
                    <i class="fa fa-map-marker" aria-hidden="true"></i>
                </div>
                <p>3481 Melrose Place, Beverly Hills, <span>New York City 90210.</span></p>
            </div>
            <div class="col-md-4 w3ls_footer_grid_left">
                <div class="wthree_footer_grid_left">
                    <i class="fa fa-phone" aria-hidden="true"></i>
                </div>
                <p>+(000) 123 4565 32 <span>+(010) 123 4565 35</span></p>
            </div>
            <div class="col-md-4 w3ls_footer_grid_left">
                <div class="wthree_footer_grid_left">
                    <i class="fa fa-envelope-o" aria-hidden="true"></i>
                </div>
                <p><a href="mailto:info@example.com">info@example1.com</a>
                    <span><a href="mailto:info@example.com">info@example2.com</a></span></p>
            </div>
            <div class="clearfix"> </div>
        </div>
        <div class="agileinfo_copyright">
            <p>© 2017 Consultancy. All Rights Reserved | Design by <a href="https://w3layouts.com/">W3layouts</a></p>
        </div>
    </div>
</div>
<!-- //footer -->

<!-- start-smoth-scrolling -->
<!-- js -->
<script type="text/javascript" src="<?php echo e(asset('fontend/js/jquery-2.1.4.min.js')); ?>"></script>
<!-- //js -->
<script src="<?php echo e(asset('fontend/js/JiSlider.js')); ?>"></script>
<script>
    $(window).load(function () {
        $('#JiSlider').JiSlider({color: '#fff', start: 3, reverse: true}).addClass('ff')
    })
</script><script type="text/javascript">

    var _gaq = _gaq || [];
    _gaq.push(['_setAccount', 'UA-36251023-1']);
    _gaq.push(['_setDomainName', 'jqueryscript.net']);
    _gaq.push(['_trackPageview']);

    (function() {
        var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
        ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
        var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
    })();

</script>
<!-- stats -->
<script src="<?php echo e(asset('fontend/js/jquery.waypoints.min.js')); ?>"></script>
<script src="<?php echo e(asset('fontend/js/jquery.countup.js')); ?>"></script>
<script>
    $('.counter').countUp();
</script>
<!-- //stats -->
<script type="text/javascript">
    $(function(){
        $("#bars li .bar").each(function(key, bar){
            var percentage = $(this).data('percentage');

            $(this).animate({
                'height':percentage+'%'
            }, 1000);
        })
    })
</script>
<!-- flexisel -->
<script type="text/javascript" src="<?php echo e(asset('fontend/js/jquery.flexisel.js')); ?>"></script>
<script type="text/javascript">
    $(window).load(function() {
        $("#flexiselDemo1").flexisel({
            visibleItems: 4,
            animationSpeed: 1000,
            autoPlay: true,
            autoPlaySpeed: 3000,
            pauseOnHover: true,
            enableResponsiveBreakpoints: true,
            responsiveBreakpoints: {
                portrait: {
                    changePoint:480,
                    visibleItems: 1
                },
                landscape: {
                    changePoint:667,
                    visibleItems:2
                },
                tablet: {
                    changePoint:800,
                    visibleItems: 3
                }
            }
        });

    });
</script>
<!-- //flexisel -->
<!-- requried-jsfiles-for owl -->
<script src="<?php echo e(asset('fontend/js/owl.carousel.js')); ?>"></script>
<script>
    $(document).ready(function() {
        $("#owl-demo2").owlCarousel({
            items : 1,
            lazyLoad : false,
            autoPlay : true,
            navigation : false,
            navigationText :  false,
            pagination : true,
        });
    });
</script>
<!-- //requried-jsfiles-for owl -->


<script type="text/javascript" src="<?php echo e(asset('fontend/js/move-top.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('fontend/js/easing.js')); ?>"></script>
<script type="text/javascript">
    jQuery(document).ready(function($) {
        $(".scroll").click(function(event){
            event.preventDefault();
            $('html,body').animate({scrollTop:$(this.hash).offset().top},1000);
        });
    });
</script>
<!-- start-smoth-scrolling -->
<!-- for bootstrap working -->
<script src="<?php echo e(asset('fontend/js/bootstrap.js')); ?>"></script>
<!-- //for bootstrap working -->
<!-- here stars scrolling icon -->
<script type="text/javascript">
    $(document).ready(function() {
        /*
            var defaults = {
            containerID: 'toTop', // fading element id
            containerHoverID: 'toTopHover', // fading element hover id
            scrollSpeed: 1200,
            easingType: 'linear'
            };
        */

        $().UItoTop({ easingType: 'easeOutQuart' });

    });
</script>
<!-- //here ends scrolling icon -->

<?php echo $__env->yieldContent('additionalJS'); ?>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\dtcl\resources\views/layouts/fontend.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title'); ?>
    Menu Content - <?php echo e($menu->name); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="box">
                <form class="form-horizontal" method="POST" action="<?php echo e(route('menu_content_save', ['menu' => $menu->id])); ?>">
                    <?php echo csrf_field(); ?>

                    <textarea id="editor1" name="text_content" rows="10" cols="80"><?php echo e($menu->content); ?></textarea>

                    <div class="box-footer">
                        <button type="submit" class="btn btn-primary">Save</button>
                        <a href="<?php echo e(route('menu_content')); ?>" class="btn btn-default">Cancel</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('additionalJS'); ?>
    <!-- CK Editor -->
    <script src="<?php echo e(asset('themes/back/bower_components/ckeditor/ckeditor.js')); ?>"></script>
    <script>
        $(function () {
            CKEDITOR.replace('editor1');
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\dtcl\resources\views/admin/page_content/menu_content_details.blade.php ENDPATH**/ ?>
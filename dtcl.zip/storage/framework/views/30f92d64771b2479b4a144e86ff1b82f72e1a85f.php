<?php $__env->startSection('title'); ?>
    Add Project
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="box">
                <div class="box-header with-border">
                    <h3 class="box-title">Project Information</h3>
                </div>
                <!-- /.box-header -->
                <!-- form start -->
                <form class="form-horizontal" method="POST" enctype="multipart/form-data" action="<?php echo e(route('add_project_post')); ?>">
                    <?php echo csrf_field(); ?>

                    <div class="box-body">
                        <div class="form-group">
                            <label class="col-sm-2 control-label">Type</label>

                            <div class="col-sm-4">
                                <select class="form-control" name="type">
                                    <option value="Complete" <?php echo e(old('type') == 'Complete' ? 'selected' : ''); ?>>Complete</option>
                                    <option value="Ongoing" <?php echo e(old('type') == 'Ongoing' ? 'selected' : ''); ?>>Ongoing</option>
                                    <option value="Shortlisted" <?php echo e(old('type') == 'Shortlisted' ? 'selected' : ''); ?>>Shortlisted</option>
                                </select>
                            </div>
                        </div>

                        <div class="form-group <?php echo e($errors->has('title') ? 'has-error' :''); ?>">
                            <label class="col-sm-2 control-label">Title</label>

                            <div class="col-sm-10">
                                <input type="text" class="form-control" placeholder="Enter title"
                                       name="title" value="<?php echo e(old('title')); ?>">

                                <?php if ($errors->has('title')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('title'); ?>
                                <span class="help-block"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>
                        <div class="form-group <?php echo e($errors->has('sector') ? 'has-error' :''); ?>">
                            <label class="col-sm-2 control-label">Sector</label>

                            <div class="col-sm-10">
                                <input type="text" class="form-control" placeholder="Enter sector"
                                       name="sector" value="<?php echo e(old('sector')); ?>">

                                <?php if ($errors->has('sector')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('sector'); ?>
                                <span class="help-block"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>

                        <div class="form-group <?php echo e($errors->has('client') ? 'has-error' :''); ?>">
                            <label class="col-sm-2 control-label">Client</label>

                            <div class="col-sm-10">
                                <input type="text" class="form-control" placeholder="Enter Client"
                                       name="client" value="<?php echo e(old('client')); ?>">

                                <?php if ($errors->has('client')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('client'); ?>
                                <span class="help-block"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>

                        <div class="form-group <?php echo e($errors->has('date') ? 'has-error' :''); ?>">
                            <label class="col-sm-2 control-label">Period</label>

                            <div class="col-sm-10">
                                <input type="date" class="form-control" placeholder="Enter date"
                                       name="date" value="<?php echo e(old('date')); ?>">

                                <?php if ($errors->has('date')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('date'); ?>
                                <span class="help-block"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>

                        <div class="form-group <?php echo e($errors->has('image') ? 'has-error' :''); ?>">
                            <label class="col-sm-2 control-label">Image</label>

                            <div class="col-sm-10">
                                <input type="file" class="form-control" name="image">

                                <?php if ($errors->has('image')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('image'); ?>
                                <span class="help-block"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>



                    </div>
                    <!-- /.box-body -->

                    <div class="box-footer">
                        <button type="submit" class="btn btn-primary">Save</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('additionalJS'); ?>
    <!-- CK Editor -->
    <script src="<?php echo e(asset('themes/back/bower_components/ckeditor/ckeditor.js')); ?>"></script>
    <script>
        $(function () {
            CKEDITOR.replace('editor1');
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\dtcl\resources\views/admin/project/add.blade.php ENDPATH**/ ?>
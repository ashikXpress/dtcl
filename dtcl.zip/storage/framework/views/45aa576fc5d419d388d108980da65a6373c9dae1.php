<?php $__env->startSection('title'); ?>
    Update Our Activity
<?php $__env->stopSection(); ?>
<?php $__env->startSection('additionalCSS'); ?>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/css/bootstrap-datetimepicker.min.css">

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="box">
                <div class="box-header with-border">
                    <h3 class="box-title">Activity Information</h3>
                </div>
                <!-- /.box-header -->
                <!-- form start -->
                <form class="form-horizontal" method="POST" enctype="multipart/form-data" action="<?php echo e(route('update.our.activity',$activity->id)); ?>">
                    <?php echo csrf_field(); ?>

                    <div class="box-body">
                        <div class="form-group <?php echo e($errors->has('title') ? 'has-error' :''); ?>">
                            <label class="col-sm-2 control-label">Title</label>

                            <div class="col-sm-10">
                                <input type="text" class="form-control" placeholder="Enter title"
                                       name="title" value="<?php echo e($activity->title); ?>">

                                <?php if ($errors->has('title')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('title'); ?>
                                <span class="help-block"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>

                        <div class="form-group <?php echo e($errors->has('image1') ? 'has-error' :''); ?>">
                            <label class="col-sm-2 control-label">Image 1</label>

                            <div class="col-sm-10">
                                <input type="file" class="form-control" name="image1">

                                <?php if ($errors->has('image1')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('image1'); ?>
                                <span class="help-block"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>

                        <div class="form-group <?php echo e($errors->has('image2') ? 'has-error' :''); ?>">
                            <label class="col-sm-2 control-label">Image 2</label>

                            <div class="col-sm-10">
                                <input type="file" class="form-control" name="image2">

                                <?php if ($errors->has('image2')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('image2'); ?>
                                <span class="help-block"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>
                        <div class="form-group <?php echo e($errors->has('image3') ? 'has-error' :''); ?>">
                            <label class="col-sm-2 control-label">Image 3</label>

                            <div class="col-sm-10">
                                <input type="file" class="form-control" name="image3">

                                <?php if ($errors->has('image3')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('image3'); ?>
                                <span class="help-block"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>

                        <div class="form-group <?php echo e($errors->has('date') ? 'has-error' :''); ?>">
                            <label class="col-sm-2 control-label">Date</label>
                            <div class='col-sm-10'>
                                <input  id="datetimepicker1" name="date" value="<?php echo e(date('m/d/Y h:i:s a', strtotime($activity->date))); ?>" type='text' class="form-control date" />
                                <?php if ($errors->has('date')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('date'); ?>
                                <span class="help-block"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>

                        <div class="form-group <?php echo e($errors->has('description') ? 'has-error' :''); ?>">
                            <label class="col-sm-2 control-label">Description</label>

                            <div class="col-sm-10">
                                <textarea id="editor1" name="description" rows="10" cols="80"><?php echo e($activity->description); ?></textarea>

                                <?php if ($errors->has('description')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('description'); ?>
                                <span class="help-block"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>
                    </div>
                    <!-- /.box-body -->

                    <div class="box-footer">
                        <button type="submit" class="btn btn-primary">Update</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('additionalJS'); ?>
    <!-- CK Editor -->
    <script src="<?php echo e(asset('themes/back/bower_components/ckeditor/ckeditor.js')); ?>"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/momentjs/2.14.1/moment.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/js/bootstrap-datetimepicker.min.js"></script>

    <script>
        $(function () {
            CKEDITOR.replace('editor1');
            $('#datetimepicker1').datetimepicker({
                // format:'YYYY-MM-DD HH:MM:SS',

            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\dtcl\resources\views/admin/activity/edit_our_activity.blade.php ENDPATH**/ ?>
<?php $__env->startSection('additionalCSS'); ?>
    <style>
        img.img-r {
            max-width: 100%;
        }
        .agile_inner_grids {
            margin-top: 0;
        }
        img.img-r {
            width: 100%;
            height: 300px;
            object-fit: cover;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="banner1">

        <div class="w3_agileits_service_banner_info">
            <h2>Activity Details</h2>
        </div>
    </div>

    <div class="test">
        <div class="container">
            <div class="agile_inner_grids">
                <div class="test-gri1">
                    <div class="col-md-12">

                        <div class="agile">
                                <div class="test-grid">
                                    <div class="col-sm-4 col-xs-12 test-grid2">
                                        <img src="<?php echo e(asset('uploads/activity/'.$activity->image1)); ?>" alt="" class="img-r">
                                    </div>
                                    <div class="col-sm-4 col-xs-12 test-grid2">
                                        <img src="<?php echo e(asset('uploads/activity/'.$activity->image2)); ?>" alt="" class="img-r">
                                    </div>
                                    <div class="col-sm-4 col-xs-12 test-grid2">
                                        <img src="<?php echo e(asset('uploads/activity/'.$activity->image3)); ?>" alt="" class="img-r">
                                    </div>

                                    <div class="col-md-12 test-grid1">
                                        <h4><?php echo e($activity->title); ?> </h4>
                                        <h5><strong><?php echo e(date('d F Y h:i A', strtotime($activity->date))); ?></strong></h5>
                                        <?php echo $activity->description; ?>


                                    </div>

                                </div>
                                <div class="clearfix"></div>
                            </div>


                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\dtcl\resources\views/activity_details.blade.php ENDPATH**/ ?>
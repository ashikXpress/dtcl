<?php $__env->startSection('content'); ?>
    <div class="banner1">

        <div class="w3_agileits_service_banner_info">
            <h2><?php echo e($item->name); ?></h2>
        </div>
    </div>

    <div class="services two">
        <div class="container">
            <?php echo $item->content; ?>

        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\dtcl\resources\views/page.blade.php ENDPATH**/ ?>
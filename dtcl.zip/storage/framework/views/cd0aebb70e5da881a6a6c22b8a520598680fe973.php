<?php $__env->startSection('additionalCSS'); ?>
    <style>
        #map {
            height: 400px;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!--/ banner -->
    <div class="banner1">

        <div class="w3_agileits_service_banner_info">
            <h2>Contact Us </h2>
        </div>
    </div>

    <!--/ banner -->
    <!-- /contact -->
    <div class="inner_main_agile_section">
        <div class="container">

            <h3 class="w3l_header w3_agileits_header"> Leave a <span>Message</span></h3>
            <p class="sub_para_agile">Ipsum dolor sit amet consectetur adipisicing elit</p>
            <div class="sub_para_agile two">
            <?php if(Session::has('message')): ?>
                <div class="alert alert-success alert-dismissible">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                    <?php echo e(Session::get('message')); ?>

                </div>
                <?php endif; ?>
            </div>
            <div class="contact-form agile_inner_grids">
                <form action="<?php echo e(route('contact_post')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="fields-grid">
                        <div class="styled-input agile-styled-input-top">
                            <input type="text" name="full_name" value="<?php echo e(old('full_name')); ?>">
                            <label>Full Name <span class="text text-danger"><?php echo e($errors->first('full_name')); ?></span></label>
                            <span></span>

                        </div>
                        <div class="styled-input agile-styled-input-top">
                            <input type="text" name="phone_number" value="<?php echo e(old('phone_number')); ?>">
                            <label>Phone <span class="text text-danger"><?php echo e($errors->first('phone_number')); ?></span></label>
                            <span></span>
                        </div>
                        <div class="styled-input">
                            <input type="email" name="email" value="<?php echo e(old('email')); ?>">
                            <label>Email <span class="text text-danger"><?php echo e($errors->first('email')); ?></span></label>
                            <span></span>
                        </div>
                        <div class="styled-input">
                            <input type="text" value="<?php echo e(old('subject')); ?>" name="subject">
                            <label>Subject <span class="text text-danger"><?php echo e($errors->first('subject')); ?></span></label>
                            <span></span>
                        </div>
                        <div class="clearfix"> </div>
                    </div>
                    <div class="styled-input textarea-grid">
                        <textarea name="message"><?php echo e(old('message')); ?></textarea>
                        <label>Message <span class="text text-danger"><?php echo e($errors->first('message')); ?></span></label>
                        <span></span>
                    </div>
                    <input type="submit" value="SEND">
                </form>
            </div>
        </div>
    </div>


    <section class="ftco-section ftco-no-pb ftco-no-pt">
        <div class="px-0">
            <div id="map"></div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('additionalJS'); ?>
    <script async defer
            src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAnKKbnZogxI9jte1w5VhVfg0CyyZyJTzw&callback=initMap">
    </script>
    <script>
        // Initialize and add the map
        function initMap() {
            // The location of Uluru
            var uluru = {lat: 23.772520, lng: 90.4056818};
            // The map, centered at Uluru
            var map = new google.maps.Map(
                document.getElementById('map'), {zoom: 19, center: uluru});
            // The marker, positioned at Uluru

            var foot = new google.maps.Map(
                document.getElementById('map_footer'), {zoom: 16, center: uluru}
                );


            var image = {
                url: "<?php echo e(asset('fontend/images/299087-64.png')); ?>",
                size: new google.maps.Size(32, 38),
                scaledSize: new google.maps.Size(32, 38),
                labelOrigin: new google.maps.Point(48, 20)
            };

            var marker = new google.maps.Marker({
                position: uluru, map: map,
                icon:image,
                title:'DTCL',
                label: { color:'red', fontWeight: 'bold', fontSize: '14px', text: 'DTCL' },
            });
            var marker2 = new google.maps.Marker({
                position: uluru, map: foot,
                icon:image,
                title:'DTCL',
                label: { color:'red', fontWeight: 'bold', fontSize: '14px', text: 'DTCL' },
            });
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\dtcl\resources\views/contact.blade.php ENDPATH**/ ?>
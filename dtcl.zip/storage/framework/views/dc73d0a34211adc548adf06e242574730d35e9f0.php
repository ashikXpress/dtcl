<?php $__env->startSection('additionalCSS'); ?>


    <style>
        .row.mb-3 {
            margin-bottom: 15px;
            margin-top: 15px;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="banner1">
        <div class="w3_agileits_service_banner_info">
            <h2>Gallery</h2>
        </div>
    </div>

    <section class="ftco-section inner_main_agile_section">
        <div class="container">
            <h3 class="w3l_header w3_agileits_header">Our <span>Gallery</span></h3>
            <p class="sub_para_agile two">Ipsum dolor sit amet consectetur adipisicing elit</p>

        <?php $__currentLoopData = $items->chunk(4); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="row mb-3">
                    <?php $__currentLoopData = $row; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-3">
                            <a href="<?php echo e(asset('uploads/gallery/'.$item->image)); ?>" data-lightbox="album" data-title="<?php echo e($item->title); ?>" data-alt="<?php echo e($item->title); ?>">
                                <img src="<?php echo e(asset('uploads/gallery/thumbs/'.$item->image)); ?>" class="img-thumbnail">
                            </a>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <?php echo e($items->links()); ?>

        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('additionalJS'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\dtcl\resources\views/gallery.blade.php ENDPATH**/ ?>